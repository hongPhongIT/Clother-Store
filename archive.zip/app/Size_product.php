<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Size_product extends Model
{
    //
}
