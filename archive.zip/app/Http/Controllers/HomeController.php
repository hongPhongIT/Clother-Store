<?php

namespace App\Http\Controllers;

use App\Product;
use App\Category;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
//    public function __construct()
//    {
//        $this->middleware('auth');
//    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
       $categories = Category::get();
       return view('layouts.home-post',compact('categories'));
    }
    
    
     public function search() {
        DB::enableQueryLog();
        $products = Product::search($_GET['keyword'])->paginate(3);
        $products -> setPath('/search?keyword=' . $_GET['keyword']);
        $keyword = $_GET['keyword'];
        $laQuery = DB::getQueryLog();

        $is_search = 1;
        $categories = Category::all();
        return view('home', compact('products', 'is_search', 'keyword', 'categories'));
     }
}
