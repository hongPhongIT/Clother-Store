
   <div class="product_right">
       <div class="tab1">
           @foreach($categories as $category)
           <ul >
               <li class="sort">{{$category->name}}</li>
                  @endforeach
           </ul>
        
    </div>
