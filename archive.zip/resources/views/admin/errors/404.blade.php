@extends('layouts.app')




@section('content')



    <h1 class="text-center">Opps no page available</h1>



@stop