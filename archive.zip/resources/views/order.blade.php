@extends('layouts.home-post')

@section('content')
<div class="container-fluid">
    <div class="container">
        <div class="row">
            <div class="col-sm-8 col-md-8 col-lg-8 shipping_form">
                <div class="s_f_title">
                    <h4>Shipping address</h4>
                </div>
                <div class="row s_f_conten" style="z-index: 999">
                    <div class="col-sm-7 col-md-7 col-lg-7">
                        <form class="form-horizontal">
                            <div class="form-group">
                                <label class="control-label col-sm-5" for="name">Full Name</label>
                                <div class="col-sm-7">
                                    <input type="text" class="form-control" name="name" id="name" value="" placeholder="Enter full name ">
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-5" for="city">Province/City</label>
                                <div class="col-sm-7">
                                    <select name="city" class="form-control">
                                        <option value="">An Giang</option>
                                        <option value="">Bà Rịa - Vũng Tàu</option>
                                        <option value="">Hà Giang</option>
                                        <option value="">Bạc Liêu</option>
                                        <option value="">Bắc Ninh</option>
                                        <option value="">Bến Tre</option>
                                        <option value="">Bình Định</option>
                                        <option value="">Bình Phước</option>
                                        <option value="">Bình Thuận</option>
                                        <option value="">Cao Bằng</option>
                                        <option value="">Đắk Lắk</option>
                                        <option value="">Đắk Nông</option>
                                        <option value="">Điện Biên</option>
                                        <option value="">Đồng Nai</option>
                                        <option value="">Đồng Tháp</option>
                                        <option value="">Quảng Bình</option>
                                        <option value="">Quảng Nam</option>
                                        <option value="">Đà Nẵng</option>
                                        <option value="">Huế</option>
                                        <option value="">TP Hồ Chí Minh</option>
                                        <option value="">Sài Gòn</option>
                                        <option value="">Hà Nội</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">  
                                <label class="control-label col-sm-5" for="district">District</label>
                                <div class="col-sm-7">
                                    <select name="" class="form-control">
                                        <option value="">Quận 1</option>
                                        <option value="">Quận 2</option>
                                        <option value="">Quận 3</option>
                                        <option value="">Quận 4</option>
                                        <option value="">Quận 5</option>
                                        <option value="">Quận 6</option>
                                        <option value="">Quận 7</option>
                                        <option value="">Quận 8</option>
                                        <option value="">Quận 9</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-5" for="town">Town</label>
                                <div class="col-sm-7">
                                    <select name="town" class="form-control">
                                        <option value="">phường 1</option>
                                        <option value="">phường 2</option>
                                        <option value="">phường 3</option>
                                        <option value="">phường 4</option>
                                        <option value="">phường 5</option>
                                        <option value="">phường 6</option>
                                        <option value="">phường 7</option>
                                        <option value="">phường 8</option>
                                        <option value="">phường 9</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-5" for="receipt">Goods receipt (floor, house number, street)</label>
                                <div class="col-sm-7">
                                    <textarea class="form-control" rows="4" id="address"  placeholder="Enter address"></textarea>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-5" for="phone">Phone number</label>
                                <div class="col-sm-7">
                                    <input type="text" class="form-control" name="phone" id="phone" value="" placeholder="Enter phone number">
                                </div>
                            </div>
                        </form>
                    </div>
                    <div class="clearfix"></div>
                    <div class="row">
                        <div class="col-sm-5 col-md-5 col-lg-5" style="padding-left: 5%;">
                            <label class="control-label">Infomation shipping</label>
                            <form>
                                <div class="radio">
                                    <label><input checked='checked' type="radio" name="ship">Shipping: Free<br>Delivery is from Friday, 3 - Friday, 10 November 2017</label>
                                </div>
                                <div class="clearfix"></div>
                                <div class="radio">
                                    <label><input type="radio" name="ship">Standard Delivery: Free<br>Delivery is from Wednesday, 1 - Monday, 6 November 2017</label>
                                </div>
                            </form>
                            <form>
                                <div class="form-group">
                                    <a href="order2.html" title=""><input class="form-control btn btn-danger " type="button" name="" value="Next"></a>
                                </div>
                            </form>
                        </div>
                        <div class="col-sm-7 col-md-7 col-lg-7"></div>
                    </div>  
                </div>
            </div>
            <div class="col-sm-4 col-md-4 col-lg-4">
                <div class="order_info_form">
                    <div class="s_f_title" style="margin-left: 0;width: 100%;">
                        <h4>Order Infomation</h4>
                    </div>
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                            <th>Product</th>
                            <th>Quanlity</th>
                            <th>Price</th>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>Korean Geometric A-Line Midi Dress</td>
                                    <td>1</td>
                                    <td>300 USD</td>
                                </tr>
                            </tbody>
                        </table>
                        <div class="row">
                            <div class="fee">
                                <div class="col-md-6">
                                    <div class="label_fee">
                                        <span>Provisional</span><br>
                                        <span style="color: green;">Transport fee</span>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="lable_price">
                                        <span id="p_fee" style="float: right;">300 USD</span><br>
                                        <span id="tr_fee" style="color: green;float: right;">2 USD</span>
                                    </div>
                                </div>                
                            </div>
                        </div>
                        <div class="row">
                            <div class="fee">
                                <div class="col-md-6">
                                    <div class="label_fee">
                                        <span><b>Total</b></span><br>
                                        <span style="font-size: 80%; font-weight: bold;">(Included VAT)</span>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="lable_price">
                                        <span id="total_fee" style="color: red;font-weight: bold;float: right;">303 USD</span><br>
                                    </div>
                                </div>                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection